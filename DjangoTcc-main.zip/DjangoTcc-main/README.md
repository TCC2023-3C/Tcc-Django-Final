# Django-tcc
Projeto criado por:

Amanda;
Aline;
Caue;
Emaluele;
João Pedro Pesuto
